module.exports = {
  settings: {
    "import/resolver": {
      node: {
        paths: ["src"]
      }
    }
  }
};
