import React from "react";

import "assets/css/style.css";
import Homepage from "scenes/Homepage";
function App() {
  return (
    <div className="App">
      <Homepage></Homepage>
    </div>
  );
}

export default App;
